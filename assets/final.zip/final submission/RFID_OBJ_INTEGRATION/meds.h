
class Medical {
  private:
  char * rfid;
  char * uniqueName;
  int dosagePeriod;

  public:
  Medical() { }; // defualt constructor
  Medical(char * rxid, char * rxName, int period) {
    (*this).rfid = rxid;
    (*this).uniqueName = rxName;
    (*this).dosagePeriod = period;
  }

  boolean isMatch(char* match) {
    String _is = String( (*this).rfid );
    boolean _t = false;
    // CHECK IF RFID TAGS ARE SAME => MATCH
    if ( _is.compareTo( String(match) ) == 0) 
      _t = true;
    else 
      _t = false; // RFID TAGS NOT SAME

  return _t;
  }

  boolean dosageWhen(int timeofDay) {
    switch( (*this).dosagePeriod ) {
    case 1: 
    if (timeofDay == 8) {return true;} else return false; break;   // morning only
    
    case 2:
    if (timeofDay == 12) {return true;} else return false; break; // noon only 
    
    case 3:
    if (timeofDay == 17) {return true;} else return false; break;   // afternoon only
    
    case 4: 
    if (timeofDay == 21) {return true;} else return false;break;  // bedtime only
     
    case 5:
    if (timeofDay == 8 ||timeofDay == 12 ) {return true;}else return false; break;  // am & noon
    
    case 6: 
    if (timeofDay == 8 ||timeofDay == 17 ) {return true;}else return false; break; // am & pm
    
    case 7: 
     if (timeofDay == 8 ||timeofDay == 21) {return true;}else return false; break; // am & hs

    case 8: 
     if (timeofDay == 12||timeofDay == 17 ) {return true;} else return false; break; // mid & pm
    
    case 9: 
     if (timeofDay == 12 ||timeofDay == 21 ) {return true;}else return false; break; // mid hs

    case 10: 
     if (timeofDay == 17 ||timeofDay == 21 ) {return true; }else return false; break; // pm & hs

    case 11: 
     if (timeofDay == 8 ||timeofDay == 12 || timeofDay ==17 ) { return true; }else return false; break; // am-mid-pm

    case 12: 
     if (timeofDay == 8 ||timeofDay == 12 || timeofDay ==17  || timeofDay ==21) { return true; }else return false; break; // am-mid-pm-hs

     case 13: 
     return true; break; // anytime


    default: return false; break;
    }  
  }
}; //end of class

Medical m[3] = {
  Medical("30002980AA33", "metformin", 13),
  Medical("5500B193FF88", "rosuvastatin", 2),
  Medical("3000298B6BF9", "asa", 3),

};
